 Page({
 
  /**
   * 页面的初始数据
   */
  data: {
    city:"",
    today:"",
    future:"",
    tips:"",
    paobu:"",
    city2:"",
  },

  tzTap: function (event) {
    wx.navigateTo({
      url: '../tz/tz',
    })
  },
  

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.loadInfo();
    this.tips();
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
   
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    
  },
  loadInfo:function(){
var page=this;//用var page接住主界面下的page
    wx.getLocation({
      type: 'gcj02', //返回可以用于wx.openLocation的经纬度
      success: function (res) {
        var latitude = res.latitude
        var longitude = res.longitude
        console.log(latitude,longitude)
        page.loadCity(latitude, longitude);
        
      }
    })
    
  },
  loadCity: function (latitude, longitude){
    var page=this;
    wx.request({
      url: 'https://api.map.baidu.com/geocoder/v2/?ak=0wc3g1eZGK5K80EQlqT9Hv21sDw7p20C&location='+latitude+','+longitude+'&output=json',//百度地图api
      data: {
        x: '',
        y: ''//未使用data
      },
      header: {
        'content-type': 'application/json' // 默认值
      },
      success: function (res) {
        console.log(res.data);
        var city=res.data.result.addressComponent.city;
        city=city.replace("市","");
        console.log(city);
        page.setData({city:city});
        page.loadWeather(city);
        
      }
    })
  },
loadWeather:function(city){
  var page=this;
  wx.request({
    url: 'http://wthrcdn.etouch.cn/weather_mini?city='+city, //
    data: {
      x: '',
      y: ''
    },
    header: {
      'content-type': 'application/json' // 默认值
    },
    success: function (res) {
      console.log(res.data)
      var future=res.data.data.forecast;
      var todayInfo=future[0];
      var today=res.data.data;
      today.todayInfo=todayInfo;
      today.todayInfo.fengli = today.todayInfo.fengli.replace("<![CDATA[","");
      today.todayInfo.fengli = today.todayInfo.fengli.replace("]]>", "");
      page.setData({today:today,future:future});
      page.run(today.wendu);
    }
  })
},
run:function(x){
  var page=this;
  var paobu;
  if((x<8)&&(x>-20)){
    paobu="大侠，外边冷，建议室内跑……啥？要在外边跑？多穿！"
  }else if((x>=8)&&(x<20)){
    paobu="现在室外跑步会很凉快舒服，啥？刮风吗？卫衣啊！"
  }else if((x>=20)&&(x<26)){
    paobu="你很难找到比现在更舒服的时段了，出去吧，给你自由！"
  }else if((x>=26)&&(x<35)){
    paobu="老哥，天热，跑步记得多补水"
  }else if((x>=35)&&(x<40)){
    paobu="我觉得现在还是室内跑把，在外边怕不是要危机绳命啊！"
  }else{
    paobu="我觉得这天气室外跑可（yi）能（ding）会死"
  }
 page.setData({paobu:paobu})
},
rnd:function (n, m){
     var random = Math.floor(Math.random() * (m - n + 1) + n);
     return random;
},
tips:function(){
  var tips;
  var page=this;
  var x=page.rnd(1,7);
  console.log(x);
  if (x == 1) {
    tips = "解酒小提示乳制品会跟酒精混合产生凝固沉淀，在胃里形成保护膜阻止酒精进一步被吸收。而且乳制品里钙含量很高，可以缓解酒后烦躁。蜂蜜里边的果糖有分解和吸收酒精的作用，可解除酒后头疼头晕。酒前多吃点含脂肪酸的荤菜，脂肪酸可以和酒精发生反应能降低酒精浓度。浓茶解酒是错误的，酒和浓茶都会刺激心脏容易造成心律失常。其次茶碱有利尿作用会让乙醛进入肾脏造成损伤"
  } else if (x == 2) {
    tips = "隔夜饭的危害：空气中的微生物会进入剩饭，把饭菜里的硝酸盐转化成亚硝酸盐从而引起中毒。即使在冷藏环境下，李斯特菌和霉菌等耐冷细菌依然会大量繁殖，这也是隔夜饭腐烂的原因。反复加热的隔夜饭会使食物中细菌释放出来的化学毒素毒性更强，还会产生反式脂肪酸等致癌物质。"
  } else if (x == 3) {
    tips = "有关盐的小常识：每天摄入的食盐量不应该超过6克，否则会导致血压升高，增加患胃癌风险；盐是摄入钠的重要途径，不吃盐会造成低钠综合症；盐并不能防辐射。"
  } else if (x == 4) {
    tips = "如何预防心血管疾病：饮食上做到粗细搭配，荤素合理，调味品限钠加盐，食用健康油如玉米油。生活上关注体重，因为肥胖者高血压发病率比正常体重着高三倍以上。规律运动，有个良好的心态，劳逸结合。戒烟少酒，防寒保暖。"
  } else if (x == 5) {
    tips = "防止眼睛干涩，缓解眼部疲劳，除了适宜的光线和聪足的休息外，给眼睛补充营养也重要。注意平衡营养，平时多吃些粗粮，杂粮，红绿蔬菜，豆类，水果等含维生素、蛋白质、膳食纤维的食物。还应吃对眼睛有保健功能的食物如芝麻。芝麻性平、味甘、具有滋补肝肾，养血明目，润肠通便，益脑生髓等功效，可用于肝肾亏损，须发早白，视物模糊，眼睛干涩等症。"
  } else if (x == 6) {
    tips = "少乘电梯，多走楼梯。爬楼梯是一种非常好的锻炼形式，对心血管有益，还可以改善腿部肌肉。此外，腹部肌肉也会得到锻炼。还能增加肺活量。"
  } else if (x == 7) {
    tips = "做什么别忘一个“度”：根结底，预防慢病，关键在凡事有个“度”。度则是适度，主要体现在一吃一动上，首先饮食要适度，不要过度补营养，也不能吃得太随便。有的人在饮食上过度注意营养，但并没有考虑到补进去的东西是否能被机体彻底吸收;有的人则为方便，饮食过于简单，造成营养摄入不均衡，这些都是不对的。其次，锻炼也要讲究度，以舒服为主要目的，在自己能承受的范围内锻炼身体，过度运动不仅会加重关节等器官损伤，还可能导致猝死等意外。"
  } else {
    tips = " "
  }
  console.log(tips)
  page.setData({tips,tips})
}
})